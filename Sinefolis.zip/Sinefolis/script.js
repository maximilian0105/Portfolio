function goToHome() {
  window.location.href = 'index.html';
}

function goToPromo() {
  window.location.href = 'promo.html';
}

function goToShowing() {
  window.location.href = 'showing.html';
}

function togglePromo(card) {
  card.classList.toggle('expanded');
}

function goToPost() {
  window.location.href = 'posting.html';
}

function goToFeedback() {
  window.location.href = 'feedback.html';
}

document.querySelectorAll('.redeem-btn').forEach(button => {
  button.addEventListener('click', () => {
    alert('Promo code copied! (not really)');
  });
});

document.querySelector('.sign-in-btn')?.addEventListener('click', () => {
  alert('Sign In button clicked (not implemented yet)');
});

function toggleDetails(card) {
  document.querySelectorAll('.movie-card').forEach(c => {
    if (c !== card) {
      c.classList.remove('active');
    }
  });

  card.classList.toggle('active');
}

const clickCounts = {};

window.toggleDetails = function(card) {
  const movieId = card.dataset.movieId;

  document.querySelectorAll('.movie-card').forEach(c => {
    const id = c.dataset.movieId;
    if (c !== card) {
      c.classList.remove('active');
      if (id) clickCounts[id] = 0;
    }
  });

  const isActive = card.classList.contains('active');

  if (!isActive) {
    card.classList.add('active');
    clickCounts[movieId] = 1;
  } else {
    clickCounts[movieId]++;
    if (clickCounts[movieId] === 2) {
      window.location.href = 'schedule.html';
    }
  }
};

document.addEventListener('click', e => {
  const activeCard = document.querySelector('.movie-card.active');
  if (activeCard && !activeCard.contains(e.target)) {
    const movieId = activeCard.dataset.movieId;
    activeCard.classList.remove('active');
    if (movieId) clickCounts[movieId] = 0;
  }
});

let currentRating = 0;

function updateStars(rating) {
  const stars = document.querySelectorAll('#stars span');
  stars.forEach((star, index) => {
    star.textContent = index < rating ? '★' : '☆';
  });
}

function submitForm(event) {
  event.preventDefault();

  const comment = document.getElementById('comment').value.trim();
  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const topic = document.getElementById('topic').value;

  if (currentRating === 0) {
    alert('Please select a star rating.');
    return false;
  }

  if (comment.length < 10) {
    alert('Comment must be at least 10 characters long.');
    return false;
  }

  if (username === '' || username.length < 4 || !username.includes('@')) {
    alert('Username must be at least 4 characters and a valid username.');
    return false;
  }

  if (!email.includes('@') || !email.includes('.')) {
    alert('Please enter a valid email.');
    return false;
  }

  if (topic === '') {
    alert('Please select a topic.');
    return false;
  }

  alert('Feedback submitted successfully!');
  goToFeedback();
  return false;
}

function handleSubmit(e) {
  e.preventDefault();
  submitForm();      
}

document.addEventListener('DOMContentLoaded', () => {
  const stars = document.querySelectorAll('#stars span');
  stars.forEach((star) => {
    star.addEventListener('click', () => {
      currentRating = parseInt(star.getAttribute('data-value'));
      updateStars(currentRating);
    });
  });
});

document.querySelectorAll('#stars span').forEach(star => {
  star.addEventListener('click', () => {
    const rating = parseInt(star.dataset.value);
    currentRating = rating;
    updateStars(rating);
  });
});

function updateStars(rating) {
  document.querySelectorAll('#stars span').forEach((star, idx) => {
    star.textContent = (idx < rating) ? '★' : '☆';
  });
}