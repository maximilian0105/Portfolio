package com.ChiMatcha.app.model;

public class Branch {
    private String name;
    private String nameJp;
    private String description;
    private String address;
    private String hours;
    private String hoursExtra;
    private int imageResId;

    public Branch(String name, String nameJp, String description,
                  String address, String hours, String hoursExtra, int imageResId) {
        this.name = name;
        this.nameJp = nameJp;
        this.description = description;
        this.address = address;
        this.hours = hours;
        this.hoursExtra = hoursExtra;
        this.imageResId = imageResId;
    }

    public String getName() { return name; }
    public String getNameJp() { return nameJp; }
    public String getDescription() { return description; }
    public String getAddress() { return address; }
    public String getHours() { return hours; }
    public String getHoursExtra() { return hoursExtra; }
    public int getImageResId() { return imageResId; }
}