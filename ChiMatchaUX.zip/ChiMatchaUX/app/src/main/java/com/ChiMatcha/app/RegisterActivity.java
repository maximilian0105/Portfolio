package com.ChiMatcha.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etConfirmPassword;
    private TextView tvErrorUsername, tvErrorPassword, tvErrorConfirm;
    private Button btnRegister;
    private TextView tvLoginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        tvErrorUsername = findViewById(R.id.tv_error_username);
        tvErrorPassword = findViewById(R.id.tv_error_password);
        tvErrorConfirm = findViewById(R.id.tv_error_confirm);
        btnRegister = findViewById(R.id.btn_register);
        tvLoginLink = findViewById(R.id.tv_login_link);

        btnRegister.setOnClickListener(v -> validateRegister());

        tvLoginLink.setOnClickListener(v -> {
            finish();
        });
    }

    private void validateRegister() {
        tvErrorUsername.setText("");
        tvErrorPassword.setText("");
        tvErrorConfirm.setText("");

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirm = etConfirmPassword.getText().toString().trim();

        boolean valid = true;

        if (TextUtils.isEmpty(username)) {
            tvErrorUsername.setText(getString(R.string.error_username_empty));
            valid = false;
        } else if (username.length() <= 6) {
            tvErrorUsername.setText(getString(R.string.error_username_length));
            valid = false;
        }

        if (TextUtils.isEmpty(password)) {
            tvErrorPassword.setText(getString(R.string.error_password_empty));
            valid = false;
        }

        if (TextUtils.isEmpty(confirm)) {
            tvErrorConfirm.setText(getString(R.string.error_confirm_empty));
            valid = false;
        } else if (!password.equals(confirm)) {
            tvErrorConfirm.setText(getString(R.string.error_password_mismatch));
            valid = false;
        }

        if (!valid) return;

        SharedPreferences prefs = getSharedPreferences("ChiMatchaPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("username", username);
        editor.putString("password", password);
        editor.apply();

        showRegisterSuccess(username);
    }

    private void showRegisterSuccess(String username) {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_register_success);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
        );
        dialog.getWindow().setGravity(android.view.Gravity.CENTER);
        dialog.setCancelable(false);
        dialog.show();

        new android.os.Handler().postDelayed(() -> {
            dialog.dismiss();
            LoginActivity.LOGGED_IN_USERNAME = username;
            Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
            finish();
        }, 2000);
    }
}