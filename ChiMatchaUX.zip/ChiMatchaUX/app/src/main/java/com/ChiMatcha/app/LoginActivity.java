package com.ChiMatcha.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    public static String LOGGED_IN_USERNAME = "";

    private EditText etUsername, etPassword;
    private TextView tvErrorUsername, tvErrorPassword;
    private Button btnLogin;
    private TextView tvRegisterLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        tvErrorUsername = findViewById(R.id.tv_error_username);
        tvErrorPassword = findViewById(R.id.tv_error_password);
        btnLogin = findViewById(R.id.btn_login);
        tvRegisterLink = findViewById(R.id.tv_register_link);

        btnLogin.setOnClickListener(v -> validateLogin());

        tvRegisterLink.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void validateLogin() {
        tvErrorUsername.setText("");
        tvErrorPassword.setText("");

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        boolean valid = true;

        if (TextUtils.isEmpty(username)) {
            tvErrorUsername.setText(getString(R.string.error_username_empty));
            valid = false;
        } else if (username.length() <= 6) {
            tvErrorUsername.setText(getString(R.string.error_username_length));
            valid = false;
        }

        if (TextUtils.isEmpty(password)) {
            tvErrorPassword.setText(getString(R.string.error_password_empty));
            valid = false;
        }

        if (!valid) return;

        SharedPreferences prefs = getSharedPreferences("ChiMatchaPrefs", MODE_PRIVATE);
        String savedUsername = prefs.getString("username", "");
        String savedPassword = prefs.getString("password", "");

        if (savedUsername.isEmpty()) {
            tvErrorUsername.setText("No account found. Please register first.");
            return;
        }

        if (username.equals(savedUsername) && password.equals(savedPassword)) {
            LOGGED_IN_USERNAME = username;
            showLoginSuccess();
        } else {
            tvErrorPassword.setText("Invalid username or password");
        }
    }

    private void showLoginSuccess() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_success);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
        );
        dialog.getWindow().setGravity(android.view.Gravity.CENTER);
        dialog.setCancelable(false);
        dialog.show();

        new android.os.Handler().postDelayed(() -> {
            dialog.dismiss();
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            intent.putExtra("username", LOGGED_IN_USERNAME);
            startActivity(intent);
            finish();
        }, 2000);
    }
}