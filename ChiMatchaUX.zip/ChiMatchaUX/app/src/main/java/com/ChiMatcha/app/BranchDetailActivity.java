package com.ChiMatcha.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BranchDetailActivity extends AppCompatActivity {

    private TextView btnBack;
    private ImageView ivBranch;
    private TextView tvBranchName, tvBranchDesc, tvBranchAddress, tvBranchHours, tvBranchExtra;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_branch_detail);

        username = getIntent().getStringExtra("username");

        initViews();
        loadData();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btn_back);
        ivBranch = findViewById(R.id.iv_branch);
        tvBranchName = findViewById(R.id.tv_branch_name);
        tvBranchDesc = findViewById(R.id.tv_branch_desc);
        tvBranchAddress = findViewById(R.id.tv_branch_address);
        tvBranchHours = findViewById(R.id.tv_branch_hours);
        tvBranchExtra = findViewById(R.id.tv_branch_extra);

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadData() {
        String name = getIntent().getStringExtra("name");
        String desc = getIntent().getStringExtra("description");
        String address = getIntent().getStringExtra("address");
        String hours = getIntent().getStringExtra("hours");
        String hoursExtra = getIntent().getStringExtra("hours_extra");
        int imageRes = getIntent().getIntExtra("image", R.drawable.img_branch_suteki);

        tvBranchName.setText(name);
        tvBranchDesc.setText(desc);
        tvBranchAddress.setText(address);
        tvBranchHours.setText(hours);
        tvBranchExtra.setText(hoursExtra);
        ivBranch.setImageResource(imageRes);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}