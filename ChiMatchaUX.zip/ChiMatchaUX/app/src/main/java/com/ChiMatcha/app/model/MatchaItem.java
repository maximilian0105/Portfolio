package com.ChiMatcha.app.model;

public class MatchaItem {
    private String name;
    private String nameJp;
    private String description;
    private String price;
    private int imageResId;

    public MatchaItem(String name, String nameJp, String description, String price, int imageResId) {
        this.name = name;
        this.nameJp = nameJp;
        this.description = description;
        this.price = price;
        this.imageResId = imageResId;
    }

    public String getName() { return name; }
    public String getNameJp() { return nameJp; }
    public String getDescription() { return description; }
    public String getPrice() { return price; }
    public int getImageResId() { return imageResId; }
}