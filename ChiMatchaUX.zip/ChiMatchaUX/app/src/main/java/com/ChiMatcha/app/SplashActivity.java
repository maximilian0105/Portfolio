package com.ChiMatcha.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private static final String WELCOME_TEXT = "Welcome!";
    private static final int TYPING_DELAY = 100;
    private static final int AFTER_DELAY = 1500;

    private TextView tvWelcome;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int charIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tvWelcome = findViewById(R.id.tv_welcome);

        handler.postDelayed(this::startTyping, 800);
    }

    private void startTyping() {
        charIndex = 0;
        typeNext();
    }

    private void typeNext() {
        if (charIndex <= WELCOME_TEXT.length()) {
            tvWelcome.setText(WELCOME_TEXT.substring(0, charIndex));
            charIndex++;
            handler.postDelayed(this::typeNext, TYPING_DELAY);
        } else {
            handler.postDelayed(this::goToLogin, AFTER_DELAY);
        }
    }

    private void goToLogin() {
        startActivity(new Intent(SplashActivity.this, LoginActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}