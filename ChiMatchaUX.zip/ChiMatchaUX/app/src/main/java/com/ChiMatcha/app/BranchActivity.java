package com.ChiMatcha.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.os.Looper;
import android.os.Handler;

public class BranchActivity extends AppCompatActivity {

    private TextView tvGreeting;
    private Button btnLogout;
    private RelativeLayout layoutLogoutDialog;
    private Button btnLogoutNo, btnLogoutYes;
    private ImageView btnMenu;
    private String username;

    private boolean toriExpanded = false;
    private boolean sutekiExpanded = false;
    private boolean kaitekiExpanded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_branch);

        username = getIntent().getStringExtra("username");
        if (username == null) username = LoginActivity.LOGGED_IN_USERNAME;

        initViews();
        setGreeting();
        setupBranches();
        setupLogoutDialog();
        setupMenuButton();
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tv_greeting);
        btnLogout = findViewById(R.id.btn_logout);
        layoutLogoutDialog = findViewById(R.id.layout_logout_dialog);
        btnLogoutNo = findViewById(R.id.btn_logout_no);
        btnLogoutYes = findViewById(R.id.btn_logout_yes);
        btnMenu = findViewById(R.id.btn_menu);
    }

    private void setGreeting() {
        tvGreeting.setText("こんにちは, ");
        typeUsername(username);
    }

    private void typeUsername(String username) {
        TextView tvUsername = findViewById(R.id.tv_username);
        final Handler handler = new Handler(Looper.getMainLooper());
        final int[] index = {0};

        handler.post(new Runnable() {
            @Override
            public void run() {
                if (index[0] <= username.length()) {
                    tvUsername.setText(username.substring(0, index[0]));
                    index[0]++;
                    handler.postDelayed(this, 100);
                }
            }
        });
    }

    private void setupBranches() {
        RelativeLayout btnBranchTori = findViewById(R.id.btn_branch_tori);
        RelativeLayout btnBranchSuteki = findViewById(R.id.btn_branch_suteki);
        RelativeLayout btnBranchKaiteki = findViewById(R.id.btn_branch_kaiteki);

        ImageView imgTori = findViewById(R.id.img_branch_tori);
        ImageView imgSuteki = findViewById(R.id.img_branch_suteki);
        ImageView imgKaiteki = findViewById(R.id.img_branch_kaiteki);

        btnBranchTori.setOnClickListener(v -> {
            if (!toriExpanded) {
                imgTori.setImageResource(R.drawable.tori);
                imgSuteki.setImageResource(R.drawable.img_branch_suteki);
                imgKaiteki.setImageResource(R.drawable.img_branch_kaiteki);
                sutekiExpanded = false;
                kaitekiExpanded = false;
                toriExpanded = true;
            } else {
                openDetail(
                        "Tori, 通り",
                        "Old fashion matcha street shop",
                        "Shinjuku Street, 2A,\nShinjuku City, Tokyo, Japan",
                        "09.00 - 20.00\nMonday to Friday",
                        "",
                        R.drawable.img_branch_tori
                );
            }
        });

        btnBranchSuteki.setOnClickListener(v -> {
            if (!sutekiExpanded) {
                imgSuteki.setImageResource(R.drawable.suteki);
                imgTori.setImageResource(R.drawable.img_branch_tori);
                imgKaiteki.setImageResource(R.drawable.img_branch_kaiteki);
                toriExpanded = false;
                kaitekiExpanded = false;
                sutekiExpanded = true;
            } else {
                openDetail(
                        "Suteki, 素敵",
                        "Cute & cozy matcha shop",
                        "Shibuya Street, 11G,\nShibuya, Tokyo, Japan",
                        "10.00 - 22.00\nMonday to Sunday",
                        "Exclude national holiday",
                        R.drawable.img_branch_suteki
                );
            }
        });

        btnBranchKaiteki.setOnClickListener(v -> {
            if (!kaitekiExpanded) {
                imgKaiteki.setImageResource(R.drawable.kaiteki);
                imgTori.setImageResource(R.drawable.img_branch_tori);
                imgSuteki.setImageResource(R.drawable.img_branch_suteki);
                toriExpanded = false;
                sutekiExpanded = false;
                kaitekiExpanded = true;
            } else {
                openDetail(
                        "Kaiteki, 快適",
                        "Comfy zen matcha shop",
                        "Sapporo Street, 6B,\nSapporo, Hokkaido, Japan",
                        "08.00 - 20.00\nMonday to Friday",
                        "10.00 - 15.00\nSaturday & Sunday",
                        R.drawable.img_branch_kaiteki
                );
            }
        });
    }

    private void openDetail(String name, String desc, String address,
                            String hours, String hoursExtra, int imageRes) {
        Intent intent = new Intent(BranchActivity.this, BranchDetailActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("name", name);
        intent.putExtra("description", desc);
        intent.putExtra("address", address);
        intent.putExtra("hours", hours);
        intent.putExtra("hours_extra", hoursExtra);
        intent.putExtra("image", imageRes);
        startActivity(intent);
    }

    private void setupMenuButton() {
        LinearLayout bottomMenuBar = findViewById(R.id.bottom_menu_bar);
        Button menuBtnHome = findViewById(R.id.menu_btn_home);
        Button menuBtnItem = findViewById(R.id.menu_btn_item);

        btnMenu.setOnClickListener(v -> {
            if (bottomMenuBar.getVisibility() == View.VISIBLE) {
                bottomMenuBar.setVisibility(View.GONE);
            } else {
                bottomMenuBar.setVisibility(View.VISIBLE);
            }
        });

        menuBtnHome.setOnClickListener(v -> {
            bottomMenuBar.setVisibility(View.GONE);
            Intent intent = new Intent(BranchActivity.this, HomeActivity.class);
            intent.putExtra("username", username);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        menuBtnItem.setOnClickListener(v -> {
            bottomMenuBar.setVisibility(View.GONE);
            Intent intent = new Intent(BranchActivity.this, ItemActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });
    }

    private void setupLogoutDialog() {
        btnLogout.setOnClickListener(v -> layoutLogoutDialog.setVisibility(View.VISIBLE));
        btnLogoutNo.setOnClickListener(v -> layoutLogoutDialog.setVisibility(View.GONE));
        btnLogoutYes.setOnClickListener(v -> {
            LoginActivity.LOGGED_IN_USERNAME = "";
            Intent intent = new Intent(BranchActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(BranchActivity.this, HomeActivity.class);
        intent.putExtra("username", username);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}