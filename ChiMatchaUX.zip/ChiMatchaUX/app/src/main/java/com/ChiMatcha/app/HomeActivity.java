package com.ChiMatcha.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import com.ChiMatcha.app.adapter.CarouselAdapter;

public class HomeActivity extends AppCompatActivity {

    private TextView tvGreeting;
    private ViewPager2 viewPager;
    private ImageButton btnPrev, btnNext;
    private LinearLayout btnItems, btnBranches;
    private Button btnLogout;
    private RelativeLayout layoutLogoutDialog;
    private Button btnLogoutNo, btnLogoutYes;

    private final int[] carouselImages = {
            R.drawable.carousel1,
            R.drawable.carousel2,
            R.drawable.carousel3
    };

    private final Handler autoScrollHandler = new Handler(Looper.getMainLooper());
    private Runnable autoScrollRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        initViews();
        setGreeting();
        setupCarousel();
        setupNavigation();
        setupLogoutDialog();
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tv_greeting);
        viewPager = findViewById(R.id.viewpager_carousel);
        btnPrev = findViewById(R.id.btn_prev);
        btnNext = findViewById(R.id.btn_next);
        btnItems = findViewById(R.id.btn_items);
        btnBranches = findViewById(R.id.btn_branches);
        btnLogout = findViewById(R.id.btn_logout);
        layoutLogoutDialog = findViewById(R.id.layout_logout_dialog);
        btnLogoutNo = findViewById(R.id.btn_logout_no);
        btnLogoutYes = findViewById(R.id.btn_logout_yes);
    }

    private void setGreeting() {
        String username = getIntent().getStringExtra("username");
        if (username == null) username = LoginActivity.LOGGED_IN_USERNAME;

        // Set kanji static
        tvGreeting.setText("こんにちは, ");

        // Typing animation untuk username
        typeUsername(username);
    }

    private void typeUsername(String username) {
        TextView tvUsername = findViewById(R.id.tv_username);
        final Handler handler = new Handler(Looper.getMainLooper());
        final int[] index = {0};

        handler.post(new Runnable() {
            @Override
            public void run() {
                if (index[0] <= username.length()) {
                    tvUsername.setText(username.substring(0, index[0]));
                    index[0]++;
                    handler.postDelayed(this, 100);
                }
            }
        });
    }

    private void setupCarousel() {
        CarouselAdapter adapter = new CarouselAdapter(this, carouselImages);
        viewPager.setAdapter(adapter);

        int startPosition = CarouselAdapter.TOTAL_COUNT / 2;
        viewPager.setCurrentItem(startPosition, false);

        btnPrev.setOnClickListener(v ->
                viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true)
        );

        btnNext.setOnClickListener(v ->
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true)
        );

        autoScrollRunnable = new Runnable() {
            @Override
            public void run() {
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true);
                autoScrollHandler.postDelayed(this, 3000);
            }
        };
        autoScrollHandler.postDelayed(autoScrollRunnable, 3000);
    }

    private void setupNavigation() {
        String username = getIntent().getStringExtra("username");

        btnItems.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ItemActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        btnBranches.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, BranchActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v ->
                layoutLogoutDialog.setVisibility(View.VISIBLE)
        );
    }

    private void setupLogoutDialog() {
        btnLogoutNo.setOnClickListener(v ->
                layoutLogoutDialog.setVisibility(View.GONE)
        );

        btnLogoutYes.setOnClickListener(v -> {
            LoginActivity.LOGGED_IN_USERNAME = "";
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (autoScrollRunnable != null)
            autoScrollHandler.postDelayed(autoScrollRunnable, 3000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        autoScrollHandler.removeCallbacks(autoScrollRunnable);
    }

    @Override
    public void onBackPressed() {
        layoutLogoutDialog.setVisibility(View.VISIBLE);
    }
}