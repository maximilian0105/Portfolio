package com.ChiMatcha.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Looper;
import android.os.Handler;


public class ItemActivity extends AppCompatActivity {

    private TextView tvGreeting;
    private Button btnLogout;
    private RelativeLayout layoutLogoutDialog;
    private Button btnLogoutNo, btnLogoutYes;
    private ImageView btnMenu;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        username = getIntent().getStringExtra("username");
        if (username == null) username = LoginActivity.LOGGED_IN_USERNAME;

        initViews();
        setGreeting();
        setupItems();
        setupLogoutDialog();
        setupMenuButton();
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tv_greeting);
        btnLogout = findViewById(R.id.btn_logout);
        layoutLogoutDialog = findViewById(R.id.layout_logout_dialog);
        btnLogoutNo = findViewById(R.id.btn_logout_no);
        btnLogoutYes = findViewById(R.id.btn_logout_yes);
        btnMenu = findViewById(R.id.btn_menu);
    }

    private void setGreeting() {
        tvGreeting.setText("こんにちは, ");
        typeUsername(username);
    }

    private void typeUsername(String username) {
        TextView tvUsername = findViewById(R.id.tv_username);
        final Handler handler = new Handler(Looper.getMainLooper());
        final int[] index = {0};

        handler.post(new Runnable() {
            @Override
            public void run() {
                if (index[0] <= username.length()) {
                    tvUsername.setText(username.substring(0, index[0]));
                    index[0]++;
                    handler.postDelayed(this, 100);
                }
            }
        });
    }

    private void setupItems() {
        // Pure & Hot
        LinearLayout btnPure = findViewById(R.id.btn_pure);
        btnPure.setOnClickListener(v -> openDetail(
                "Pure&Hot", "抹茶",
                "Chi's signature\nPure extracted &\naromatic taste",
                "¥500", R.drawable.img_matcha_classic
        ));

        // Hot Latte
        LinearLayout btnLatte = findViewById(R.id.btn_latte);
        btnLatte.setOnClickListener(v -> openDetail(
                "Hot Latte", "ホットラテ",
                "Roasted matcha\npoured with smooth\nsteamed milk",
                "¥550", R.drawable.img_matcha_cappuccino
        ));

        // Frappe
        LinearLayout btnFrappe = findViewById(R.id.btn_frappe);
        btnFrappe.setOnClickListener(v -> openDetail(
                "Frappe", "フラッペ",
                "Cold blended\nmatcha with milk\ncream",
                "¥560", R.drawable.img_matcha_frappe
        ));

        // Ice Latte
        LinearLayout btnIceLatte = findViewById(R.id.btn_ice_latte);
        btnIceLatte.setOnClickListener(v -> openDetail(
                "Ice Latte", "アイスラテ",
                "Ice shaken matcha in\nsmooth milk",
                "¥550", R.drawable.img_matcha_latte
        ));
    }

    private void openDetail(String name, String nameJp, String desc, String price, int imageRes) {
        Intent intent = new Intent(ItemActivity.this, ItemDetailActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("name", name);
        intent.putExtra("name_jp", nameJp);
        intent.putExtra("description", desc);
        intent.putExtra("price", price);
        intent.putExtra("image", imageRes);
        startActivity(intent);
    }

    private void setupMenuButton() {
        LinearLayout bottomMenuBar = findViewById(R.id.bottom_menu_bar);
        Button menuBtnHome = findViewById(R.id.menu_btn_home);
        Button menuBtnBranch = findViewById(R.id.menu_btn_branch);

        btnMenu.setOnClickListener(v -> {
            if (bottomMenuBar.getVisibility() == View.VISIBLE) {
                bottomMenuBar.setVisibility(View.GONE);
            } else {
                bottomMenuBar.setVisibility(View.VISIBLE);
            }
        });

        menuBtnHome.setOnClickListener(v -> {
            bottomMenuBar.setVisibility(View.GONE);
            Intent intent = new Intent(ItemActivity.this, HomeActivity.class);
            intent.putExtra("username", username);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        menuBtnBranch.setOnClickListener(v -> {
            bottomMenuBar.setVisibility(View.GONE);
            Intent intent = new Intent(ItemActivity.this, BranchActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });
    }
    private void setupLogoutDialog() {
        btnLogout.setOnClickListener(v -> layoutLogoutDialog.setVisibility(View.VISIBLE));

        btnLogoutNo.setOnClickListener(v -> layoutLogoutDialog.setVisibility(View.GONE));

        btnLogoutYes.setOnClickListener(v -> {
            LoginActivity.LOGGED_IN_USERNAME = "";
            Intent intent = new Intent(ItemActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ItemActivity.this, HomeActivity.class);
        intent.putExtra("username", username);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}