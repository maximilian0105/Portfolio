package com.ChiMatcha.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    private TextView btnBack;
    private ImageView ivProduct;
    private TextView tvName, tvNameJp, tvDescription, tvPrice;
    private SeekBar seekbarIce, seekbarSweet;
    private Button btnMinus, btnPlus, btnOrder;
    private EditText etQuantity, etNotes;
    private RelativeLayout layoutBackDialog, layoutOrderDialog;
    private Button btnBackNo, btnBackYes;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        username = getIntent().getStringExtra("username");

        initViews();
        loadData();
        setupButtons();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btn_back);
        ivProduct = findViewById(R.id.iv_product);
        tvName = findViewById(R.id.tv_name);
        tvNameJp = findViewById(R.id.tv_name_jp);
        tvDescription = findViewById(R.id.tv_description);
        tvPrice = findViewById(R.id.tv_price);
        seekbarIce = findViewById(R.id.seekbar_ice);
        seekbarSweet = findViewById(R.id.seekbar_sweet);
        btnMinus = findViewById(R.id.btn_minus);
        btnPlus = findViewById(R.id.btn_plus);
        btnOrder = findViewById(R.id.btn_order);
        etQuantity = findViewById(R.id.et_quantity);
        etNotes = findViewById(R.id.et_notes);
        layoutBackDialog = findViewById(R.id.layout_back_dialog);
        layoutOrderDialog = findViewById(R.id.layout_order_dialog);
        btnBackNo = findViewById(R.id.btn_back_no);
        btnBackYes = findViewById(R.id.btn_back_yes);
    }

    private void loadData() {
        String name = getIntent().getStringExtra("name");
        String nameJp = getIntent().getStringExtra("name_jp");
        String desc = getIntent().getStringExtra("description");
        String price = getIntent().getStringExtra("price");
        int imageRes = getIntent().getIntExtra("image", R.drawable.img_matcha_classic);

        tvName.setText(name);
        tvNameJp.setText(nameJp);
        tvDescription.setText(desc);
        tvPrice.setText(price);
        ivProduct.setImageResource(imageRes);
    }

    private void setupButtons() {
        // Back button
        btnBack.setOnClickListener(v -> layoutBackDialog.setVisibility(View.VISIBLE));

        // Back dialog
        btnBackNo.setOnClickListener(v -> layoutBackDialog.setVisibility(View.GONE));
        btnBackYes.setOnClickListener(v -> {
            finish();
        });

        // Quantity minus
        btnMinus.setOnClickListener(v -> {
            String val = etQuantity.getText().toString().trim();
            int qty = val.isEmpty() ? 1 : Integer.parseInt(val);
            if (qty > 1) etQuantity.setText(String.valueOf(qty - 1));
        });

        // Quantity plus
        btnPlus.setOnClickListener(v -> {
            String val = etQuantity.getText().toString().trim();
            int qty = val.isEmpty() ? 1 : Integer.parseInt(val);
            etQuantity.setText(String.valueOf(qty + 1));
        });

        // Order button
        btnOrder.setOnClickListener(v -> validateOrder());
    }

    private void validateOrder() {
        String qtyStr = etQuantity.getText().toString().trim();

        if (TextUtils.isEmpty(qtyStr)) {
            etQuantity.setError("Quantity must be filled");
            return;
        }

        int qty = Integer.parseInt(qtyStr);
        if (qty <= 0) {
            etQuantity.setError("Quantity must not be 0");
            return;
        }

        // Show order success dialog
        layoutOrderDialog.setVisibility(View.VISIBLE);

        new Handler().postDelayed(() -> {
            layoutOrderDialog.setVisibility(View.GONE);
            Intent intent = new Intent(ItemDetailActivity.this, ItemActivity.class);
            intent.putExtra("username", username);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }, 2000);
    }

    @Override
    public void onBackPressed() {
        layoutBackDialog.setVisibility(View.VISIBLE);
    }
}